#!/usr/bin/env/python
import csv
import re

DATA = []  # lists "level", "title", "page"

FILE = './tabula-toc-0.csv'

rx_dotfill = re.compile(r'[. ]+$')

with open(FILE, 'r') as in_fh:
    reader = csv.reader(in_fh)
    prev_row = None
    combine_with_prev = False
    for row in reader:
        if combine_with_prev:
            title = prev_row[0].strip() + " " + row[0].strip()
            page = row[1].strip()
        else:
            title = row[0]
            page = row[1].strip()
        title = rx_dotfill.sub('', title)
        if page == '':
            combine_with_prev = True
        else:
            combine_with_prev = False
            if title.startswith("Preface"):
                level = 0
            else:
                rx_level = re.compile(r'^[\d.]+')
                m = rx_level.match(title)
                try:
                    level = m.group().count('.')
                except AttributeError:
                    from IPython.terminal.debugger import set_trace
                    set_trace()
                    print(title)
            DATA.append([level, title, page])
        prev_row = row

with open("./clean/" + FILE, 'w') as out_fh:
    writer = csv.writer(out_fh)
    for row in DATA:
        writer.writerow(row)
