#!/usr/bin/env/python
import csv
import re


FILES = ['./tabula-toc-5.csv', './tabula-toc-8.csv', './tabula-toc-9.csv']

rx_dotfill = re.compile(r'[. ]+$')

for file in FILES:

    DATA = []  # lists "level", "title", "page"

    with open(file, 'r') as in_fh:
        reader = csv.reader(in_fh)
        prev_row = None
        combine_with_prev = False
        for row in reader:
            assert row[1].strip() == ''
            if combine_with_prev:
                title = (prev_row[0].strip() + " " + row[0].strip()).strip()
                page = row[2].strip()
            else:
                title = row[0].strip()
                page = row[2].strip()
            title = title.strip()
            title = rx_dotfill.sub('', title).strip()
            if page == '':
                combine_with_prev = True
            else:
                combine_with_prev = False
                rx_level = re.compile(r'^[\d.]+')
                m = rx_level.match(title)
                try:
                    level = m.group().count('.')
                except AttributeError:
                    level = 1
                DATA.append([level, title, page])
            prev_row = row

    with open("./clean/" + file, 'w') as out_fh:
        writer = csv.writer(out_fh)
        for row in DATA:
            writer.writerow(row)
