#!/usr/bin/env/python
import csv
import re


FILES = ['./tabula-toc-2.csv', './tabula-toc-6.csv', './tabula-toc-7.csv', ]

rx_dotfill = re.compile(r'[. ]+$')
rx_page = re.compile(r'\d+$')

for file in FILES:

    DATA = []  # lists "level", "title", "page"

    with open(file, 'r') as in_fh:
        reader = csv.reader(in_fh)
        prev_row = None
        combine_with_prev = False
        for row in reader:
            if combine_with_prev:
                title_page = " ".join(
                    [c.strip() for c in prev_row] +
                    [c.strip() for c in row]).strip()
            else:
                title_page = " ".join([c.strip() for c in row]).strip()
            try:
                page = rx_page.search(title_page).group()
                title = rx_page.sub('', title_page).strip()
            except AttributeError:
                page = ''
                title = title_page
            title = rx_dotfill.sub('', title).strip()
            if page == '':
                combine_with_prev = True
            else:
                combine_with_prev = False
                rx_level = re.compile(r'^[\d.]+')
                m = rx_level.match(title)
                try:
                    level = m.group().count('.')
                except AttributeError:
                    level = 1
                DATA.append([level, title, page])
            prev_row = row

    with open("./clean/" + file, 'w') as out_fh:
        writer = csv.writer(out_fh)
        for row in DATA:
            writer.writerow(row)
